// SEN TEW — Mobile App (React Native + Expo)
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { ScrollView, StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';

const EMERALD = '#0F6B4E';
const GOLD = '#D4A574';

export default function App() {
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.logo}>SEN TEW</Text>
        <Text style={styles.langSelector}>FR</Text>
      </View>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.heroBanner}>
          <Text style={styles.heroTitle}>Soldes Ramadan</Text>
          <Text style={styles.heroSub}>Jusqu'à -50% • Livraison gratuite</Text>
        </View>

        <View style={styles.categories}>
          {['Mode', 'Électronique', 'Maison', 'Beauté', 'Alimentation'].map(c => (
            <TouchableOpacity key={c} style={styles.catChip}>
              <Text style={styles.catText}>{c}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Produits en vedette</Text>
        <View style={styles.productGrid}>
          {[
            { name: 'Robe Wax Premium', price: '25 000', old: '40 000', discount: '-37%' },
            { name: 'Sac cuir artisanal', price: '18 500', old: '28 000', discount: '-34%' },
            { name: 'Bijoux dorés', price: '8 000', old: '12 000', discount: '-33%' },
            { name: 'Boubou homme', price: '35 000', old: '50 000', discount: '-30%' },
          ].map(p => (
            <TouchableOpacity key={p.name} style={styles.productCard}>
              <View style={styles.productImg} />
              <Text style={styles.discount}>{p.discount}</Text>
              <Text style={styles.pname}>{p.name}</Text>
              <Text style={styles.pprice}>{p.price} FCFA</Text>
              <Text style={styles.poldprice}>{p.old}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
      <TouchableOpacity style={styles.aiFab}>
        <Text style={styles.aiFabIcon}>✨</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FAFAF7' },
  header: { backgroundColor: '#0A0A0A', paddingTop: 50, paddingHorizontal: 20, paddingBottom: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  logo: { color: GOLD, fontSize: 22, fontWeight: '900', letterSpacing: 3 },
  langSelector: { color: GOLD, borderWidth: 1, borderColor: GOLD, paddingHorizontal: 12, paddingVertical: 4, borderRadius: 6 },
  scroll: { padding: 16 },
  heroBanner: { backgroundColor: EMERALD, padding: 24, borderRadius: 16, marginBottom: 20 },
  heroTitle: { color: GOLD, fontSize: 28, fontWeight: '900' },
  heroSub: { color: 'white', marginTop: 4 },
  categories: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  catChip: { backgroundColor: 'white', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: '#E5E7EB' },
  catText: { color: '#0A0A0A', fontSize: 13 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: EMERALD, marginBottom: 12 },
  productGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  productCard: { width: '48%', backgroundColor: 'white', borderRadius: 12, padding: 12, marginBottom: 12 },
  productImg: { height: 120, backgroundColor: '#E5E7EB', borderRadius: 8, marginBottom: 8 },
  discount: { position: 'absolute', top: 16, right: 16, backgroundColor: GOLD, color: '#0A0A0A', paddingHorizontal: 8, paddingVertical: 2, fontWeight: 'bold', fontSize: 11, borderRadius: 4 },
  pname: { fontSize: 13, color: '#0A0A0A', marginBottom: 4 },
  pprice: { fontSize: 16, fontWeight: 'bold', color: EMERALD },
  poldprice: { fontSize: 12, color: '#6B7280', textDecorationLine: 'line-through' },
  aiFab: { position: 'absolute', right: 20, bottom: 30, width: 56, height: 56, borderRadius: 28, backgroundColor: GOLD, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 8 },
  aiFabIcon: { fontSize: 24 },
});
