/**
 * SEN TEW — Service de paiements multi-méthodes
 * Wave, Orange Money, Free Money, Wizall, M-Pesa, Visa/MC, SENBANC, SENCRYPT, Stripe, PayPal
 */
import { Injectable, Logger } from '@nestjs/common';
import axios from 'axios';
import Stripe from 'stripe';

export type PaymentMethod =
  | 'wave' | 'orange_money' | 'free_money' | 'wizall'
  | 'mpesa' | 'mtn_momo' | 'airtel_money'
  | 'visa' | 'mastercard'
  | 'senbanc' | 'sencrypt'
  | 'stripe' | 'paypal'
  | 'cash_on_delivery';

export interface PaymentRequest {
  amount: number;
  currency: 'XOF' | 'EUR' | 'USD' | 'NGN' | 'KES' | 'MAD';
  method: PaymentMethod;
  userId: string;
  orderId: string;
  installments?: 1 | 2 | 3;  // Paiement 2x ou 3x sans frais
  giftCardCode?: string;
  promoCode?: string;
}

@Injectable()
export class PaymentsService {
  private readonly logger = new Logger(PaymentsService.name);
  private stripe: Stripe;

  constructor() {
    this.stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2023-10-16' });
  }

  async processPayment(req: PaymentRequest) {
    this.logger.log(`Processing ${req.method} payment of ${req.amount} ${req.currency}`);

    // Application bons cadeaux / promos
    let finalAmount = req.amount;
    if (req.promoCode) finalAmount = await this.applyPromoCode(finalAmount, req.promoCode);
    if (req.giftCardCode) finalAmount = await this.applyGiftCard(finalAmount, req.giftCardCode);

    // Routage selon méthode
    switch (req.method) {
      case 'wave': return this.payWithWave(req, finalAmount);
      case 'orange_money': return this.payWithOrangeMoney(req, finalAmount);
      case 'free_money': return this.payWithFreeMoney(req, finalAmount);
      case 'wizall': return this.payWithWizall(req, finalAmount);
      case 'mpesa': return this.payWithMpesa(req, finalAmount);
      case 'visa':
      case 'mastercard':
      case 'stripe': return this.payWithStripe(req, finalAmount);
      case 'senbanc': return this.payWithSenbanc(req, finalAmount);
      case 'sencrypt': return this.payWithSencrypt(req, finalAmount);
      case 'paypal': return this.payWithPayPal(req, finalAmount);
      case 'cash_on_delivery': return this.cashOnDelivery(req, finalAmount);
      default: throw new Error(`Unsupported payment method: ${req.method}`);
    }
  }

  // ----- Mobile Money locaux -----
  private async payWithWave(req: PaymentRequest, amount: number) {
    const resp = await axios.post('https://api.wave.com/v1/checkout/sessions',
      {
        amount,
        currency: req.currency,
        success_url: `${process.env.APP_URL}/orders/${req.orderId}/success`,
        error_url: `${process.env.APP_URL}/orders/${req.orderId}/error`,
        client_reference: req.orderId,
      },
      { headers: { Authorization: `Bearer ${process.env.WAVE_API_KEY}` }});
    return { provider: 'wave', checkout_url: resp.data.wave_launch_url, sessionId: resp.data.id };
  }

  private async payWithOrangeMoney(req: PaymentRequest, amount: number) {
    // Intégration Orange Money Sénégal API
    return { provider: 'orange_money', status: 'pending_ussd', ussd_code: '#144#' };
  }

  private async payWithFreeMoney(req: PaymentRequest, amount: number) {
    return { provider: 'free_money', status: 'pending', tx_id: `FM-${req.orderId}` };
  }

  private async payWithWizall(req: PaymentRequest, amount: number) {
    return { provider: 'wizall', status: 'pending', tx_id: `WZ-${req.orderId}` };
  }

  private async payWithMpesa(req: PaymentRequest, amount: number) {
    // Safaricom Daraja API
    return { provider: 'mpesa', status: 'stk_push_sent' };
  }

  // ----- Cartes / Stripe -----
  private async payWithStripe(req: PaymentRequest, amount: number) {
    // Paiement 2x/3x via Stripe Klarna ou méthode interne
    if (req.installments && req.installments > 1) {
      return this.processInstallments(req, amount);
    }
    const intent = await this.stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency: req.currency.toLowerCase(),
      metadata: { orderId: req.orderId, userId: req.userId },
      payment_method_types: ['card'],
    });
    return { provider: 'stripe', clientSecret: intent.client_secret, paymentIntentId: intent.id };
  }

  // ----- Paiement échelonné 2x ou 3x sans frais -----
  private async processInstallments(req: PaymentRequest, amount: number) {
    const n = req.installments!;
    const installmentAmount = Math.round((amount / n) * 100) / 100;
    const schedule = [];
    const today = new Date();
    for (let i = 0; i < n; i++) {
      const due = new Date(today);
      due.setMonth(due.getMonth() + i);
      schedule.push({ index: i + 1, amount: installmentAmount, dueDate: due.toISOString() });
    }
    // TODO : éligibilité crédit via IA (score utilisateur)
    return { provider: 'installments', plan: `${n}x_sans_frais`, schedule, total: amount, fees: 0 };
  }

  // ----- Écosystème SEN -----
  private async payWithSenbanc(req: PaymentRequest, amount: number) {
    // Appel API interne SENBANC (gRPC ou REST)
    const resp = await axios.post(`${process.env.SENBANC_API_URL}/payments/internal`,
      { amount, currency: req.currency, userId: req.userId, ref: req.orderId },
      { headers: { 'X-Sen-Service-Key': process.env.SEN_INTERNAL_KEY }});
    return { provider: 'senbanc', txId: resp.data.transactionId, status: 'completed' };
  }

  private async payWithSencrypt(req: PaymentRequest, amount: number) {
    // Conversion crypto -> FCFA via SENCRYPT
    return { provider: 'sencrypt', txId: `SC-${req.orderId}`, status: 'pending_crypto_confirmation' };
  }

  // ----- Autres -----
  private async payWithPayPal(req: PaymentRequest, amount: number) {
    return { provider: 'paypal', approve_url: 'https://www.paypal.com/checkoutnow?token=...' };
  }

  private async cashOnDelivery(req: PaymentRequest, amount: number) {
    return { provider: 'cash_on_delivery', status: 'awaiting_delivery', amount };
  }

  // ----- Bons cadeaux et codes promo -----
  private async applyGiftCard(amount: number, code: string): Promise<number> {
    // TODO : valider code en DB + déduire montant
    this.logger.log(`Applying gift card ${code}`);
    return amount;
  }

  private async applyPromoCode(amount: number, code: string): Promise<number> {
    this.logger.log(`Applying promo code ${code}`);
    return amount;
  }
}
