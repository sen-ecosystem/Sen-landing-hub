import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductsModule } from './products/products.module';
import { OrdersModule } from './orders/orders.module';
import { PaymentsModule } from './payments/payments.module';
import { UsersModule } from './users/users.module';
import { SellersModule } from './sellers/sellers.module';
import { LiveModule } from './live/live.module';
import { AiModule } from './ai/ai.module';
import { LogisticsModule } from './logistics/logistics.module';
import { RefundsModule } from './refunds/refunds.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      url: process.env.DATABASE_URL,
      autoLoadEntities: true,
      synchronize: process.env.NODE_ENV !== 'production',
    }),
    UsersModule,
    SellersModule,
    ProductsModule,
    OrdersModule,
    PaymentsModule,
    LiveModule,
    AiModule,
    LogisticsModule,
    RefundsModule,
  ],
})
export class AppModule {}
