// SEN TEW — Page d'accueil Next.js
import Head from 'next/head';
import { useState } from 'react';

const EMERALD = '#0F6B4E';
const GOLD = '#D4A574';

const PRODUCTS = [
  { id: 1, name: 'Robe Wax Premium Dakar', price: 25000, old: 40000, seller: 'Boutique Aïcha', verified: true },
  { id: 2, name: 'Sac cuir artisanal', price: 18500, old: 28000, seller: 'Cuir Touba', verified: true },
  { id: 3, name: 'Bijoux dorés Plateau', price: 8000, old: 12000, seller: 'Or & Argent SN', verified: false },
  { id: 4, name: 'Boubou homme Korité', price: 35000, old: 50000, seller: 'Mode Saint-Louis', verified: true },
];

export default function Home() {
  const [lang, setLang] = useState('fr');

  return (
    <>
      <Head><title>SEN TEW — La marketplace de l&apos;Afrique</title></Head>
      <header style={{ background: '#0A0A0A', padding: 16, color: 'white', display: 'flex', justifyContent: 'space-between' }}>
        <div style={{ fontWeight: 900, color: GOLD, fontSize: 22, letterSpacing: 3 }}>SEN TEW</div>
        <input placeholder="Rechercher un produit..." style={{ flex: 1, margin: '0 24px', padding: 10, borderRadius: 8, border: 'none' }} />
        <select value={lang} onChange={e => setLang(e.target.value)} style={{ background: 'transparent', color: GOLD, border: `1px solid ${GOLD}`, padding: 6, borderRadius: 6 }}>
          <option value="fr">🇫🇷 FR</option>
          <option value="en">🇬🇧 EN</option>
          <option value="ar">🇸🇦 AR</option>
          <option value="wo">🇸🇳 Wolof</option>
        </select>
      </header>
      <div style={{ padding: 32, background: 'linear-gradient(135deg, #0F6B4E, #0A4D38)', color: 'white', textAlign: 'center' }}>
        <h1 style={{ fontSize: 48, color: GOLD, fontWeight: 900 }}>Soldes Ramadan -50%</h1>
        <p>Livraison gratuite Dakar • Paiement en 2x ou 3x sans frais</p>
      </div>
      <main style={{ padding: 32, background: '#FAFAF7' }}>
        <h2 style={{ color: EMERALD }}>Produits en vedette</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 20, marginTop: 20 }}>
          {PRODUCTS.map(p => (
            <div key={p.id} style={{ background: 'white', padding: 16, borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,.05)' }}>
              <div style={{ height: 180, background: '#E5E7EB', borderRadius: 8, marginBottom: 12, position: 'relative' }}>
                <span style={{ position: 'absolute', top: 8, right: 8, background: GOLD, color: '#0A0A0A', padding: '2px 8px', borderRadius: 4, fontWeight: 'bold', fontSize: 11 }}>
                  -{Math.round((1 - p.price / p.old) * 100)}%
                </span>
              </div>
              <h4>{p.name}</h4>
              <p style={{ color: '#6B7280', fontSize: 13 }}>{p.seller} {p.verified && '⭐'}</p>
              <div style={{ marginTop: 8 }}>
                <span style={{ color: EMERALD, fontSize: 18, fontWeight: 'bold' }}>{p.price.toLocaleString()} FCFA</span>
                <span style={{ color: '#9CA3AF', textDecoration: 'line-through', marginLeft: 8, fontSize: 13 }}>{p.old.toLocaleString()}</span>
              </div>
              <button style={{ marginTop: 12, width: '100%', background: GOLD, padding: 10, border: 'none', borderRadius: 8, fontWeight: 'bold', cursor: 'pointer' }}>
                Ajouter au panier
              </button>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
