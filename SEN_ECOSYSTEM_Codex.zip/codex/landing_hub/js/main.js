// SEN ECOSYSTEM — Interactivité de base
document.addEventListener('DOMContentLoaded', ()=>{
  // Header rétractile au scroll
  const header = document.querySelector('.site-header');
  window.addEventListener('scroll', ()=>{
    if(window.scrollY > 50) header.style.boxShadow = '0 4px 24px rgba(0,0,0,.3)';
    else header.style.boxShadow = 'none';
  });

  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', e=>{
      const id = a.getAttribute('href');
      if(id.length>1){
        const target = document.querySelector(id);
        if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'})}
      }
    });
  });

  // Animation cards on intersect
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(en=>{ if(en.isIntersecting){en.target.style.opacity=1;en.target.style.transform='translateY(0)'} });
  },{threshold:0.1});
  document.querySelectorAll('.app-card,.stat-card,.sec-item').forEach(el=>{
    el.style.opacity=0;el.style.transform='translateY(30px)';el.style.transition='all .6s ease-out';
    obs.observe(el);
  });
});
