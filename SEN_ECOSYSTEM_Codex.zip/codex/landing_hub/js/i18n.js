// SEN ECOSYSTEM — Système i18n 15 langues
const I18N = {
  fr: {
    "nav.ecosystem":"Écosystème","nav.security":"Sécurité","nav.download":"Télécharger",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Commerce. Banque. Crypto. Une Afrique unifiée, sécurisée, multilingue.",
    "hero.cta1":"Télécharger les apps","hero.cta2":"Découvrir l'écosystème",
    "eco.title":"3 plateformes. 1 compte. Infinies possibilités.","eco.sub":"SEN ID unifié, wallet partagé, écosystème connecté.",
    "tew.desc":"Marketplace e-commerce africaine premium",
    "tew.f1":"Live Shopping vendeurs","tew.f2":"Paiement 2x/3x sans frais","tew.f3":"Assistant IA shopping","tew.f4":"Logistique Afrique + International","tew.f5":"SEN Verified (Bronze/Gold/Platinum)",
    "banc.desc":"Néobanque africaine multi-devises (Revolut-grade)",
    "banc.f1":"14 devises + carte Metal Gold","banc.f2":"Transferts diaspora sans frais cachés","banc.f3":"Crédit IA en 60 secondes","banc.f4":"Bourses africaines + mondiales","banc.f5":"Tax reporting IA multi-pays",
    "crypt.desc":"Exchange crypto africain Binance + eToro",
    "crypt.f1":"Achat crypto via Mobile Money","crypt.f2":"Staking jusqu'à 25% APY","crypt.f3":"P2P escrow sécurisé","crypt.f4":"Copy Trading & CopyPortfolios","crypt.f5":"Token natif SENC",
    "stats.title":"L'Afrique en chiffres","stats.pop":"Population africaine","stats.unbanked":"Adultes non bancarisés","stats.mm":"Mobile money 2025","stats.lang":"Langues supportées",
    "sec.title":"Sécurité de niveau mondial","sec.s1":"Chiffrement bout en bout","sec.s2":"Face ID + empreinte + 2FA","sec.s3":"500+ signaux analysés/transaction","sec.s4":"Assurance jusqu'à 100k USDT","sec.s5":"80%+ des fonds crypto","sec.s6":"RGPD + CCPA + BCEAO + FATF",
    "dl.title":"Téléchargez les 3 apps","dl.sub":"Un seul compte SEN ID pour les trois plateformes."
  },
  en: {
    "nav.ecosystem":"Ecosystem","nav.security":"Security","nav.download":"Download",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Commerce. Banking. Crypto. A unified, secure, multilingual Africa.",
    "hero.cta1":"Download the apps","hero.cta2":"Explore the ecosystem",
    "eco.title":"3 platforms. 1 account. Infinite possibilities.","eco.sub":"Unified SEN ID, shared wallet, connected ecosystem.",
    "tew.desc":"Premium African e-commerce marketplace",
    "tew.f1":"Seller Live Shopping","tew.f2":"2x/3x interest-free payment","tew.f3":"AI shopping assistant","tew.f4":"Africa + International logistics","tew.f5":"SEN Verified (Bronze/Gold/Platinum)",
    "banc.desc":"Multi-currency African neobank (Revolut-grade)",
    "banc.f1":"14 currencies + Metal Gold card","banc.f2":"Diaspora transfers, no hidden fees","banc.f3":"AI credit in 60 seconds","banc.f4":"African + global stock markets","banc.f5":"Multi-country AI tax reporting",
    "crypt.desc":"African crypto exchange Binance + eToro grade",
    "crypt.f1":"Buy crypto with Mobile Money","crypt.f2":"Staking up to 25% APY","crypt.f3":"Secure P2P escrow","crypt.f4":"Copy Trading & CopyPortfolios","crypt.f5":"Native SENC token",
    "stats.title":"Africa in numbers","stats.pop":"African population","stats.unbanked":"Unbanked adults","stats.mm":"Mobile money 2025","stats.lang":"Languages supported",
    "sec.title":"World-class security","sec.s1":"End-to-end encryption","sec.s2":"Face ID + fingerprint + 2FA","sec.s3":"500+ signals per transaction","sec.s4":"Insurance up to 100k USDT","sec.s5":"80%+ of crypto funds","sec.s6":"GDPR + CCPA + BCEAO + FATF",
    "dl.title":"Download the 3 apps","dl.sub":"One SEN ID account for all three platforms."
  },
  ar: {
    "nav.ecosystem":"النظام","nav.security":"الأمان","nav.download":"تحميل",
    "hero.title":"سن إيكوسيستم","hero.sub":"تجارة. مصرفية. عملات مشفرة. إفريقيا موحدة وآمنة ومتعددة اللغات.",
    "hero.cta1":"تحميل التطبيقات","hero.cta2":"اكتشف النظام البيئي",
    "eco.title":"3 منصات. حساب واحد. إمكانيات لا حصر لها.","eco.sub":"معرف SEN موحد، محفظة مشتركة، نظام بيئي متصل.",
    "tew.desc":"سوق التجارة الإلكترونية الإفريقي الفاخر",
    "banc.desc":"البنك الرقمي الإفريقي متعدد العملات",
    "crypt.desc":"منصة تبادل العملات المشفرة الإفريقية"
  },
  pt: {
    "nav.ecosystem":"Ecossistema","nav.security":"Segurança","nav.download":"Baixar",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Comércio. Banca. Cripto. Uma África unificada, segura, multilingue.",
    "tew.desc":"Marketplace africano premium","banc.desc":"Neobanco africano multi-moeda","crypt.desc":"Exchange cripto africana"
  },
  es: {
    "nav.ecosystem":"Ecosistema","nav.security":"Seguridad","nav.download":"Descargar",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Comercio. Banca. Cripto. Una África unificada, segura, multilingüe.",
    "tew.desc":"Marketplace africano premium","banc.desc":"Neobanco africano multi-moneda","crypt.desc":"Exchange cripto africana"
  },
  wo: {
    "nav.ecosystem":"Ekosistem","nav.security":"Kaaraange","nav.download":"Téléchargé",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Tejjti. Bànk. Crypto. Afrig bu benn, bu wér, ñépp dégg.",
    "tew.desc":"Marché elektroonik bu Afrig","banc.desc":"Bànk bu mobil ci Afrig","crypt.desc":"Tejjti crypto ci Afrig"
  },
  sw: {
    "nav.ecosystem":"Mfumo","nav.security":"Usalama","nav.download":"Pakua",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Biashara. Benki. Krypto. Afrika iliyounganishwa, salama, ya lugha nyingi.",
    "tew.desc":"Soko la kibiashara la Afrika","banc.desc":"Benki ya kidijitali ya Afrika","crypt.desc":"Soko la krypto la Afrika"
  },
  ha: {
    "nav.ecosystem":"Tsarin","nav.security":"Tsaro","nav.download":"Saukar da",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Kasuwanci. Banki. Crypto. Afirka mai haɗin kai, mai aminci, mai harsuna da yawa.",
    "tew.desc":"Kasuwar lantarki ta Afirka","banc.desc":"Bankin dijital na Afirka","crypt.desc":"Musayar crypto ta Afirka"
  },
  yo: {
    "nav.ecosystem":"Ètò","nav.security":"Ààbò","nav.download":"Gba",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Òwò. Báńkì. Crypto. Áfríkà tí ó dàpọ̀, tí ó ní ààbò, oníjèdè púpọ̀.",
    "tew.desc":"Ọjà ìtajà orí ayélujára","banc.desc":"Báńkì dìjítà","crypt.desc":"Pàṣípààrọ̀ crypto"
  },
  am: {
    "nav.ecosystem":"ሥርዓተ-ምህዳር","nav.security":"ደህንነት","nav.download":"አውርድ",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"ንግድ። ባንክ። ክሪፕቶ። የተዋሐደች፣ ደህንነቷ የተጠበቀ፣ ብዙ ቋንቋ ተናጋሪ አፍሪካ።",
    "tew.desc":"የአፍሪካ ኤሌክትሮኒክ ገበያ","banc.desc":"የአፍሪካ ዲጂታል ባንክ","crypt.desc":"የአፍሪካ ክሪፕቶ ልውውጥ"
  },
  zu: {
    "nav.ecosystem":"I-Ecosystem","nav.security":"Ukuphepha","nav.download":"Landa",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Ezohwebo. Ibhange. I-Crypto. I-Afrika ehlangene, ephephile, enezilimi eziningi.",
    "tew.desc":"Imakethe yase-Afrika","banc.desc":"Ibhange ledijithali lase-Afrika","crypt.desc":"Ukushintshana kwe-crypto"
  },
  bm: {
    "nav.ecosystem":"Sigida","nav.security":"Lakana","nav.download":"A jigin",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Jago. Banki. Crypto. Farafinna kelen, lakananen, kan caman.",
    "tew.desc":"Farafinna jago yɔrɔ","banc.desc":"Farafinna telefɔni banki","crypt.desc":"Farafinna crypto jago"
  },
  ff: {
    "nav.ecosystem":"Sangirde","nav.security":"Kisal","nav.download":"Aawto",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Njulaagu. Bankaaji. Crypto. Afrik gootal, hisii, demɗe keewɗe.",
    "tew.desc":"Luumo elektoroonik Afrik","banc.desc":"Banke mobil Afrik","crypt.desc":"Wattindirde crypto"
  },
  ln: {
    "nav.ecosystem":"Ekosistemi","nav.security":"Bokɛngɛli","nav.download":"Kitisa",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Mombongo. Banki. Crypto. Afríka esangani, ya bokɛngɛli, ya minɔkɔ mingi.",
    "tew.desc":"Zandó ya Afríka","banc.desc":"Banki ya simbisi","crypt.desc":"Zandó ya crypto"
  },
  ber: {
    "nav.ecosystem":"Anagraw","nav.security":"Taɣellist","nav.download":"Sider",
    "hero.title":"SEN ECOSYSTEM","hero.sub":"Tahanut. Abanki. Crypto. Tafrika yedduklen, taɣellsant, s waṭas n tutlayin.",
    "tew.desc":"Tahanut tilektrunit n Tafrika","banc.desc":"Abanki amaziri n Tafrika","crypt.desc":"Beddel n crypto"
  }
};

const RTL_LANGS = ['ar'];

function applyLang(lang){
  if(!I18N[lang]) return;
  const t = I18N[lang];
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    if(t[key]) el.textContent = t[key];
  });
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL_LANGS.includes(lang) ? 'rtl' : 'ltr';
  localStorage.setItem('sen_lang', lang);
}

document.addEventListener('DOMContentLoaded', ()=>{
  const sel = document.getElementById('langSelector');
  const saved = localStorage.getItem('sen_lang') || (navigator.language.startsWith('en')?'en':'fr');
  sel.value = saved;
  applyLang(saved);
  sel.addEventListener('change', e=>applyLang(e.target.value));
});
