module github.com/sen-ecosystem/sencrypt

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	github.com/google/uuid v1.5.0
	github.com/segmentio/kafka-go v0.4.47
	github.com/redis/go-redis/v9 v9.4.0
	github.com/jackc/pgx/v5 v5.5.2
	github.com/shopspring/decimal v1.3.1
	github.com/gorilla/websocket v1.5.1
	github.com/golang-jwt/jwt/v5 v5.2.0
)
