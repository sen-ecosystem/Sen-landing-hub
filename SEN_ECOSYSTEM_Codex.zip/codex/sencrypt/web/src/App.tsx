// SENCRYPT — Frontend Web (React + TypeScript)
import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';

const EMERALD = '#0F6B4E';
const GOLD = '#D4A574';
const BLACK = '#0A0A0A';

function Dashboard() {
  return (
    <div style={{ padding: 32, backgroundColor: BLACK, color: 'white', minHeight: '100vh' }}>
      <h1 style={{ color: GOLD }}>SENCRYPT — Dashboard</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginTop: 24 }}>
        {[
          { sym: 'BTC',  price: '$42,850.50', change: '+3.24%' },
          { sym: 'ETH',  price: '$2,340.00',  change: '+1.80%' },
          { sym: 'USDT', price: '$1.00',      change: '0.00%' },
          { sym: 'SENC', price: '$0.45',      change: '+18.20%' },
        ].map((c) => (
          <div key={c.sym} style={{ padding: 20, backgroundColor: '#1a1a1a', borderRadius: 12, borderLeft: `4px solid ${GOLD}` }}>
            <h3>{c.sym}</h3>
            <p style={{ fontSize: 24, color: GOLD, fontWeight: 'bold' }}>{c.price}</p>
            <span style={{ color: c.change.startsWith('+') ? '#22c55e' : '#ef4444' }}>{c.change}</span>
          </div>
        ))}
      </div>
      <h2 style={{ color: GOLD, marginTop: 40 }}>Marchés</h2>
      <ul style={{ marginTop: 16, lineHeight: 2 }}>
        <li><Link to="/trade/BTCUSDT" style={{ color: GOLD }}>BTC/USDT</Link></li>
        <li><Link to="/trade/ETHUSDT" style={{ color: GOLD }}>ETH/USDT</Link></li>
        <li><Link to="/trade/SENCUSDT" style={{ color: GOLD }}>SENC/USDT</Link></li>
        <li><Link to="/p2p" style={{ color: GOLD }}>P2P Marketplace</Link></li>
        <li><Link to="/earn" style={{ color: GOLD }}>Earn & Staking</Link></li>
        <li><Link to="/ai" style={{ color: GOLD }}>Assistant IA Trader</Link></li>
      </ul>
    </div>
  );
}

function Trade() {
  return <div style={{ padding: 32, backgroundColor: BLACK, color: 'white', minHeight: '100vh' }}>
    <h1 style={{ color: GOLD }}>Trading — Order book + Chart TradingView</h1>
    <p>Intégration TradingView lightweight-charts + WebSocket order book temps réel</p>
  </div>;
}

function AIAssistant() {
  return <div style={{ padding: 32, backgroundColor: BLACK, color: 'white', minHeight: '100vh' }}>
    <h1 style={{ color: GOLD }}>SENC AI Trader</h1>
    <p>Analyse technique IA + Fear & Greed Index + recommandations DCA</p>
  </div>;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/trade/:symbol" element={<Trade />} />
        <Route path="/ai" element={<AIAssistant />} />
      </Routes>
    </BrowserRouter>
  );
}
