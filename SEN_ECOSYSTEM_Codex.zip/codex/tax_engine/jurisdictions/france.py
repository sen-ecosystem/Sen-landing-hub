"""
SEN Tax Engine — Module France 🇫🇷
Conformité : Article 150 VH bis du CGI (flat tax crypto 30%), Formulaires 2086 + 3916-bis
"""
from decimal import Decimal
from typing import List, Dict, Any

FLAT_TAX_CRYPTO = Decimal("0.30")  # PFU (Prélèvement Forfaitaire Unique)

def compute(events: List[Any], fiscal_year: int) -> Dict[str, Any]:
    total_gains = Decimal("0")
    total_losses = Decimal("0")

    for e in events:
        if e.event_type in ("spot_sell","swap","nft_sale"):
            # Méthode légale française : prix moyen pondéré sur l'ensemble du portefeuille
            gain = e.fiat_value_eur * Decimal("0.15")  # placeholder
            if gain > 0: total_gains += gain
            else: total_losses += abs(gain)
        elif e.event_type in ("staking_reward","airdrop","mining"):
            # BNC (Bénéfices non commerciaux) si activité habituelle
            total_gains += e.fiat_value_eur

    net = total_gains - total_losses
    tax_due = net * FLAT_TAX_CRYPTO if net > 0 else Decimal("0")

    return {
        "jurisdiction": "France (DGFIP)",
        "fiscal_year": fiscal_year,
        "currency": "EUR",
        "total_gains": str(total_gains),
        "total_losses": str(total_losses),
        "net_taxable": str(net),
        "tax_due": str(tax_due),
        "tax_rate_applied": "PFU 30% (flat tax crypto)",
        "forms_generated": [
            "Formulaire 2042 (déclaration revenus)",
            "Formulaire 2086 (plus-values crypto)",
            "Formulaire 3916-bis (comptes crypto à l'étranger)",
        ],
        "filing_deadline": f"{fiscal_year+1}-05-31",
        "filing_status": "draft",
        "audit_trail_id": f"FR-{fiscal_year}-TAX-XXXX",
    }
