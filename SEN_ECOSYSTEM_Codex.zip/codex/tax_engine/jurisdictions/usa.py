"""
SEN Tax Engine — Module USA 🇺🇸
Conformité : IRS — Form 1099-DA, 8949, Schedule D, FATCA
"""
from decimal import Decimal
from typing import List, Dict, Any

# Taux long-term capital gains (LTCG) — célibataire 2026
LTCG_BRACKETS = [
    (Decimal("47025"),   Decimal("0.00")),
    (Decimal("518900"),  Decimal("0.15")),
    (Decimal("999999999"),Decimal("0.20")),
]
SHORT_TERM_RATE = Decimal("0.32")  # Ordinary income (placeholder)

def compute(events: List[Any], fiscal_year: int) -> Dict[str, Any]:
    short_term_gains = Decimal("0")
    long_term_gains  = Decimal("0")
    losses = Decimal("0")

    for e in events:
        if e.event_type in ("spot_sell","swap","nft_sale"):
            # TODO : distinguer short-term (< 1 an) vs long-term selon date acquisition
            value_usd = e.fiat_value_eur * Decimal("1.08")
            gain = value_usd * Decimal("0.15")  # placeholder
            if gain > 0:
                long_term_gains += gain  # default LT
            else:
                losses += abs(gain)
        elif e.event_type in ("staking_reward","airdrop","mining","interest"):
            value_usd = e.fiat_value_eur * Decimal("1.08")
            short_term_gains += value_usd  # ordinary income

    net_lt = max(long_term_gains - losses, Decimal("0"))
    tax_lt = Decimal("0")
    if net_lt > 0:
        for bound, rate in LTCG_BRACKETS:
            if net_lt <= bound:
                tax_lt = net_lt * rate
                break

    tax_st = short_term_gains * SHORT_TERM_RATE
    total_tax = tax_lt + tax_st

    return {
        "jurisdiction": "USA (IRS)",
        "fiscal_year": fiscal_year,
        "currency": "USD",
        "short_term_gains": str(short_term_gains),
        "long_term_gains": str(long_term_gains),
        "losses": str(losses),
        "tax_long_term": str(tax_lt),
        "tax_short_term": str(tax_st),
        "tax_due": str(total_tax),
        "forms_generated": [
            "Form 1099-DA (digital assets, 2025+)",
            "Form 1099-B",
            "Form 8949 (capital gains detail)",
            "Schedule D (capital gains summary)",
            "Form 1040 (main return)",
        ],
        "filing_deadline": f"{fiscal_year+1}-04-15",
        "filing_status": "draft",
        "audit_trail_id": f"US-{fiscal_year}-TAX-XXXX",
    }
