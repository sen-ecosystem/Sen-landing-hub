"""SEN Tax Engine — Module Afrique multi-pays 🌍 (UEMOA + CEMAC + autres)"""
from decimal import Decimal
from typing import List, Dict, Any

# Taux par pays (capital gains / revenus de capitaux mobiliers)
AFRICA_RATES = {
    "CI": Decimal("0.20"), # Côte d'Ivoire DGI
    "ML": Decimal("0.18"), # Mali
    "BF": Decimal("0.20"), # Burkina Faso
    "BJ": Decimal("0.18"), # Bénin
    "TG": Decimal("0.20"), # Togo
    "NE": Decimal("0.20"), # Niger
    "NG": Decimal("0.10"), # Nigeria FIRS
    "KE": Decimal("0.15"), # Kenya KRA
    "GH": Decimal("0.15"), # Ghana GRA
    "TZ": Decimal("0.10"), # Tanzanie TRA
    "UG": Decimal("0.20"), # Ouganda URA
    "RW": Decimal("0.30"), # Rwanda RRA
    "ZA": Decimal("0.18"), # Afrique du Sud SARS (effective CGT)
    "MA": Decimal("0.20"), # Maroc DGI
    "TN": Decimal("0.20"), # Tunisie
    "DZ": Decimal("0.15"), # Algérie
    "EG": Decimal("0.225"), # Égypte ETA
}

def compute(events: List[Any], country: str, fiscal_year: int) -> Dict[str, Any]:
    rate = AFRICA_RATES.get(country.upper(), Decimal("0.20"))
    gains = sum((e.fiat_value_eur * Decimal("0.15") for e in events
                 if e.event_type in ("spot_sell","swap","nft_sale")), Decimal("0"))
    tax = gains * rate
    return {
        "jurisdiction": f"{country} (African Tax Administration)",
        "fiscal_year": fiscal_year,
        "currency_reporting": "Local currency converted",
        "total_gains_eur": str(gains),
        "tax_rate_applied": str(rate),
        "tax_due_eur": str(tax),
        "ataf_cooperation": True,  # African Tax Administration Forum
        "forms_generated": [f"National tax declaration {country}"],
        "filing_status": "draft",
    }
