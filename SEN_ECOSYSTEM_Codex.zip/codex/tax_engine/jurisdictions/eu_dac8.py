"""SEN Tax Engine — Module DAC8 UE 🇪🇺 — Directive 2023/2226 (crypto reporting auto)"""
from decimal import Decimal
from typing import List, Dict, Any

COUNTRY_RATES = {
    "DE": Decimal("0.25"),  # Abgeltungsteuer + Soli (Anlage SO)
    "BE": Decimal("0.33"),
    "IT": Decimal("0.26"),  # plus-values crypto
    "ES": Decimal("0.23"),  # 19-26% selon montants
    "NL": Decimal("0.31"),  # box 3 (wealth tax)
    "PT": Decimal("0.28"),
    "IE": Decimal("0.33"),  # CGT
    "AT": Decimal("0.275"),
    "FI": Decimal("0.30"),  # 30-34%
    "SE": Decimal("0.30"),
    "DK": Decimal("0.42"),
    "PL": Decimal("0.19"),
    "LU": Decimal("0.42"),
    "GR": Decimal("0.15"),
    "CY": Decimal("0.20"),
    "CZ": Decimal("0.15"),
    "SK": Decimal("0.19"),
    "HU": Decimal("0.15"),
    "RO": Decimal("0.10"),
    "BG": Decimal("0.10"),
    "HR": Decimal("0.10"),
    "SI": Decimal("0.275"),
    "EE": Decimal("0.20"),
    "LV": Decimal("0.20"),
    "LT": Decimal("0.15"),
    "MT": Decimal("0.35"),
}

def compute(events: List[Any], country: str, fiscal_year: int) -> Dict[str, Any]:
    rate = COUNTRY_RATES.get(country.upper(), Decimal("0.25"))
    gains = sum((e.fiat_value_eur * Decimal("0.15") for e in events
                 if e.event_type in ("spot_sell","swap","nft_sale")), Decimal("0"))
    tax = gains * rate

    return {
        "jurisdiction": f"{country} (DAC8 EU reporting)",
        "fiscal_year": fiscal_year, "currency": "EUR",
        "total_gains": str(gains), "tax_rate_applied": str(rate),
        "tax_due": str(tax),
        "dac8_reporting_required": True,
        "crs_reporting_required": True,
        "forms_generated": [f"DAC8 report ({country})", "National tax return"],
        "filing_status": "draft",
    }
