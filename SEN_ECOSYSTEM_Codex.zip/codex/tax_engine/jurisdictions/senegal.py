"""
SEN Tax Engine — Module Sénégal 🇸🇳
Conformité : Code Général des Impôts (CGI), DGID, Loi 2008-12
"""
from decimal import Decimal
from typing import List, Dict, Any

# Barème IR Sénégal (résidents) — 2026 (en FCFA)
IR_BRACKETS_FCFA = [
    (Decimal("630000"),   Decimal("0.00")),
    (Decimal("1500000"),  Decimal("0.20")),
    (Decimal("4000000"),  Decimal("0.30")),
    (Decimal("8000000"),  Decimal("0.35")),
    (Decimal("13500000"), Decimal("0.37")),
    (Decimal("999999999"),Decimal("0.40")),
]

# Plus-values sur crypto/actions : prélèvement libératoire 20% (à confirmer DGID)
CAPITAL_GAINS_TAX_RATE = Decimal("0.20")

# Taux EUR -> FCFA fixe (peg BCEAO)
EUR_TO_FCFA = Decimal("655.957")

def compute(events: List[Any], fiscal_year: int) -> Dict[str, Any]:
    gains_fcfa = Decimal("0")
    losses_fcfa = Decimal("0")

    for e in events:
        if e.event_type in ("spot_sell","swap","nft_sale"):
            value_fcfa = e.fiat_value_eur * EUR_TO_FCFA
            # TODO : calcul plus-value réelle (prix d'acquisition vs cession, FIFO)
            estimated_gain = value_fcfa * Decimal("0.15")  # placeholder
            if estimated_gain > 0:
                gains_fcfa += estimated_gain
            else:
                losses_fcfa += abs(estimated_gain)

        elif e.event_type in ("staking_reward","airdrop","mining","interest"):
            # Revenus de capitaux mobiliers - imposés comme revenu
            value_fcfa = e.fiat_value_eur * EUR_TO_FCFA
            gains_fcfa += value_fcfa

    net_taxable = gains_fcfa - losses_fcfa
    tax_due = net_taxable * CAPITAL_GAINS_TAX_RATE if net_taxable > 0 else Decimal("0")

    return {
        "jurisdiction": "Sénégal (DGID)",
        "fiscal_year": fiscal_year,
        "currency": "FCFA",
        "total_gains": str(gains_fcfa),
        "total_losses": str(losses_fcfa),
        "net_taxable": str(net_taxable),
        "tax_due": str(tax_due),
        "tax_rate_applied": "20% (prélèvement libératoire)",
        "forms_generated": [
            "Déclaration IR (formulaire DGID)",
            "Annexe plus-values mobilières",
            "Déclaration IRVM si dividendes",
        ],
        "filing_deadline": f"{fiscal_year+1}-04-30",
        "filing_status": "draft",
        "audit_trail_id": f"SN-{fiscal_year}-TAX-XXXX",
    }
