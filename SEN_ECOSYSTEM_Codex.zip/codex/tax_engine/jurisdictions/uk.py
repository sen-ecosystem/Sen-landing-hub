"""SEN Tax Engine — Module UK 🇬🇧 — HMRC Self Assessment + CGT"""
from decimal import Decimal
from typing import List, Dict, Any

CGT_ALLOWANCE_2026 = Decimal("3000")  # GBP annual allowance
CGT_RATE_BASIC = Decimal("0.10")
CGT_RATE_HIGHER = Decimal("0.20")

def compute(events: List[Any], fiscal_year: int) -> Dict[str, Any]:
    gains = sum((e.fiat_value_eur * Decimal("0.85") * Decimal("0.15") for e in events
                 if e.event_type in ("spot_sell","swap","nft_sale")), Decimal("0"))
    taxable = max(gains - CGT_ALLOWANCE_2026, Decimal("0"))
    tax = taxable * CGT_RATE_HIGHER
    return {
        "jurisdiction": "UK (HMRC)", "fiscal_year": fiscal_year, "currency": "GBP",
        "total_gains": str(gains), "cgt_allowance_applied": str(CGT_ALLOWANCE_2026),
        "net_taxable": str(taxable), "tax_due": str(tax),
        "forms_generated": ["SA100 (Self Assessment)","SA108 (Capital Gains Summary)"],
        "filing_deadline": f"{fiscal_year+1}-01-31",
        "filing_status": "draft",
    }
