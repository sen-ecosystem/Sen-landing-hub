"""
AI Classifier — Classification d'événements imposables + détection résidence fiscale
Utilise GPT-4 + règles déterministes pour identifier la nature fiscale de chaque transaction
"""
import os
from typing import Dict, Any

# Règles déterministes pour classification rapide
EVENT_RULES = {
    "spot_buy":       {"taxable": False, "category": "acquisition"},
    "spot_sell":      {"taxable": True,  "category": "capital_gain"},
    "swap":           {"taxable": True,  "category": "capital_gain"},
    "staking_reward": {"taxable": True,  "category": "income"},
    "airdrop":        {"taxable": True,  "category": "income"},
    "mining":         {"taxable": True,  "category": "income"},
    "interest":       {"taxable": True,  "category": "income"},
    "nft_sale":       {"taxable": True,  "category": "capital_gain"},
    "gift_received":  {"taxable": False, "category": "gift"},
    "loan_received":  {"taxable": False, "category": "loan"},
    "transfer_self":  {"taxable": False, "category": "transfer"},
}

def classify_event(event: Dict[str, Any]) -> Dict[str, Any]:
    et = event.get("event_type","")
    rule = EVENT_RULES.get(et, {"taxable": True, "category": "unknown"})

    # Pour les cas ambigus, on appellerait l'IA GPT-4 pour décider
    # (placeholder ici — l'appel OpenAI est commenté pour démo offline)
    return {
        "event_type": et,
        "taxable": rule["taxable"],
        "category": rule["category"],
        "explanation_fr": _explain_fr(et, rule["category"]),
        "explanation_en": _explain_en(et, rule["category"]),
    }

def detect_residency(user_id: str, kyc_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Détermine la résidence fiscale en croisant :
     - Pays déclaré
     - Adresse de résidence (justificatif)
     - Téléphone (indicatif)
     - IP geolocation historique
     - Nationalité (CNI/passeport)
    """
    declared_country = kyc_data.get("declared_country","").upper()
    id_country       = kyc_data.get("id_document_country","").upper()
    address_country  = kyc_data.get("proof_of_address_country","").upper()
    phone_country    = kyc_data.get("phone_country","").upper()
    ip_country       = kyc_data.get("dominant_ip_country","").upper()

    # Logique : majoritaire entre 5 signaux
    votes = [declared_country, id_country, address_country, phone_country, ip_country]
    votes = [v for v in votes if v]
    if not votes:
        return {"confidence": 0, "primary_country": None}

    from collections import Counter
    top = Counter(votes).most_common(1)[0]
    confidence = top[1] / len(votes)

    # Détecter diaspora : ID Sénégal + adresse Europe/USA
    secondary = None
    if id_country == "SN" and address_country in ("FR","US","GB","BE","IT","ES","CA","DE"):
        secondary = "SN"

    is_us_person = (
        id_country == "US" or address_country == "US" or
        kyc_data.get("born_in_us") or kyc_data.get("us_citizen")
    )

    return {
        "user_id": user_id,
        "primary_country": top[0],
        "secondary_country": secondary,
        "confidence": round(confidence, 2),
        "is_diaspora": bool(secondary),
        "is_us_person": bool(is_us_person),
        "signals_used": {
            "declared": declared_country, "id": id_country,
            "address": address_country, "phone": phone_country, "ip": ip_country,
        }
    }

def _explain_fr(et: str, cat: str) -> str:
    msgs = {
        "capital_gain": f"Événement « {et} » : plus-value imposable selon le pays de résidence.",
        "income": f"Événement « {et} » : revenu imposable comme revenu de capitaux mobiliers.",
        "acquisition": f"Événement « {et} » : acquisition, non imposable mais à conserver pour le calcul futur.",
        "gift": "Don/cadeau : non imposable pour le récepteur (sauf seuils nationaux).",
        "loan": "Prêt reçu : non imposable.",
        "transfer": "Transfert entre comptes propres : non imposable.",
    }
    return msgs.get(cat, "Événement à classifier manuellement.")

def _explain_en(et: str, cat: str) -> str:
    msgs = {
        "capital_gain": f"Event '{et}': taxable capital gain per country of residence.",
        "income": f"Event '{et}': taxable as income from capital.",
        "acquisition": f"Event '{et}': acquisition, not taxable but retained for future calculation.",
        "gift": "Gift received: not taxable for recipient (subject to national thresholds).",
        "loan": "Loan received: not taxable.",
        "transfer": "Transfer between own accounts: not taxable.",
    }
    return msgs.get(cat, "Event requires manual classification.")
