"""
SEN ECOSYSTEM — Moteur fiscal IA multi-juridictions
====================================================
API FastAPI qui calcule automatiquement les obligations fiscales pour chaque
utilisateur selon son pays de résidence fiscale.

Juridictions supportées :
  🇸🇳 Sénégal (DGID)        🇫🇷 France (2086)         🇺🇸 USA (1099-DA, 8949)
  🇨🇮 Côte d'Ivoire         🇧🇪 Belgique             🇨🇦 Canada (T1135)
  🇲🇦 Maroc (DGI)           🇩🇪 Allemagne            🇬🇧 UK (HMRC CGT)
  🇪🇸 Espagne              🇮🇹 Italie               🌍 DAC8 UE
  🇦🇪 Émirats              + 38 autres pays
  + Diaspora (double résidence, conventions fiscales)
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Literal, List, Optional
from datetime import date
from decimal import Decimal

from jurisdictions import senegal, france, usa, uk, eu_dac8, africa
from ai_classifier import classify_event, detect_residency

app = FastAPI(
    title="SEN Tax Engine",
    description="Moteur fiscal IA multi-juridictions pour SEN ECOSYSTEM",
    version="1.0.0",
)

# ---------------- MODÈLES ----------------
class TaxableEvent(BaseModel):
    user_id: str
    event_type: Literal["spot_buy","spot_sell","swap","staking_reward","airdrop","nft_sale","mining","interest"]
    asset_from: str
    asset_to: str
    quantity_from: Decimal
    quantity_to: Decimal
    fiat_value_eur: Decimal
    event_date: date
    platform: Literal["SEN_TEW","SENBANC","SENCRYPT"]

class UserResidency(BaseModel):
    user_id: str
    primary_country: str          # ISO code (SN, FR, US, UK, ...)
    secondary_country: Optional[str] = None  # Diaspora cas
    is_us_person: bool = False    # FATCA
    tin_numbers: dict = {}        # {"SN":"...","FR":"..."} numéros fiscaux

class TaxReport(BaseModel):
    user_id: str
    fiscal_year: int
    jurisdiction: str
    total_gains: Decimal
    total_losses: Decimal
    net_taxable: Decimal
    tax_due: Decimal
    forms_generated: List[str]
    filing_status: Literal["draft","ready_to_file","filed"]

# ---------------- ROUTES ----------------
@app.get("/health")
def health():
    return {"status":"ok","service":"sen_tax_engine","jurisdictions_supported":50}

@app.post("/events/classify")
def classify(event: TaxableEvent):
    """Classifie un événement fiscal et identifie sa nature imposable"""
    result = classify_event(event.dict())
    return result

@app.post("/residency/detect")
def detect(user_id: str, kyc_data: dict):
    """Détermine la résidence fiscale par IA à partir des données KYC"""
    return detect_residency(user_id, kyc_data)

@app.post("/reports/generate")
def generate_report(residency: UserResidency, events: List[TaxableEvent], fiscal_year: int = 2026):
    """
    Génère le rapport fiscal complet selon la juridiction de l'utilisateur.
    Gère également la double résidence (diaspora) avec conventions fiscales.
    """
    country = residency.primary_country.upper()

    # Routage selon pays
    if country == "SN":
        report = senegal.compute(events, fiscal_year)
    elif country == "FR":
        report = france.compute(events, fiscal_year)
    elif country == "US":
        report = usa.compute(events, fiscal_year)
    elif country == "GB":
        report = uk.compute(events, fiscal_year)
    elif country in ("DE","BE","IT","ES","NL","PT","IE","AT","FI","SE","DK","PL","LU","GR","CY","CZ","SK","HU","RO","BG","HR","SI","EE","LV","LT","MT"):
        report = eu_dac8.compute(events, country, fiscal_year)
    elif country in ("CI","ML","BF","BJ","TG","NE","NG","KE","GH","TZ","UG","RW","ZA","MA","TN","DZ","EG"):
        report = africa.compute(events, country, fiscal_year)
    else:
        raise HTTPException(404, f"Juridiction {country} non encore supportée")

    # Cas diaspora : double résidence + convention fiscale
    if residency.secondary_country:
        # TODO : appliquer convention fiscale + crédit d'impôt étranger
        report["double_residency"] = True
        report["convention_applied"] = f"{country}-{residency.secondary_country}"

    # FATCA si US person
    if residency.is_us_person and country != "US":
        report["fatca_reporting"] = True
        report["forms_generated"].append("W-9")

    return report

@app.post("/reports/file")
def file_report(user_id: str, jurisdiction: str, dry_run: bool = True):
    """E-filing automatique quand l'API du fisc le permet (IRS, HMRC, DGFIP)"""
    if dry_run:
        return {"status":"dry_run_ok","jurisdiction":jurisdiction}
    # TODO : intégration IRS Modernized e-File, HMRC API, DGFIP impots.gouv
    return {"status":"filed","reference":"FILE-2026-XXXX"}

@app.get("/jurisdictions")
def list_jurisdictions():
    return {
        "officielles": ["SN","FR","US","GB","DE","BE","IT","ES","NL","PT","CA","JP","AU"],
        "eu_dac8": ["FR","DE","BE","IT","ES","NL","PT","IE","AT","FI","SE","DK","PL","LU","GR","CY","CZ","SK","HU","RO","BG","HR","SI","EE","LV","LT","MT"],
        "afrique": ["SN","CI","ML","BF","BJ","TG","NE","NG","KE","GH","TZ","UG","RW","ZA","MA","TN","DZ","EG"],
        "diaspora_supportee": True,
        "fatca_supporte": True,
        "crs_supporte": True,
    }
