# 🌍 SEN ECOSYSTEM — CODEX (Code Source Opérationnel)

> Code source de démarrage des 3 plateformes : **SEN TEW**, **SENBANC**, **SENCRYPT** + le **site web hub multilingue**.

---

## 📁 Structure du codex

```
codex/
├── README.md                  ← ce fichier
├── docker-compose.yml         ← stack locale complète
├── .env.example               ← variables d'environnement type
│
├── landing_hub/               ← site web hub multilingue 15 langues (OPÉRATIONNEL)
│   ├── index.html
│   ├── css/main.css
│   ├── js/i18n.js             ← 15 langues
│   └── js/main.js
│
├── sen_tew/                   ← marketplace e-commerce (Next.js + NestJS)
│   ├── backend/               ← NestJS (Node.js + TypeScript)
│   │   ├── src/main.ts
│   │   ├── src/app.module.ts
│   │   ├── src/products/      ← service produits
│   │   ├── src/orders/        ← service commandes
│   │   ├── src/payments/      ← Wave, Orange Money, Stripe, SENBANC
│   │   └── package.json
│   ├── web/                   ← Next.js 14
│   │   ├── pages/index.tsx
│   │   └── package.json
│   └── mobile/                ← React Native + Expo
│       ├── App.tsx
│       └── package.json
│
├── senbanc/                   ← néobanque (Kotlin + Flutter)
│   ├── backend/               ← Spring Boot Kotlin
│   │   ├── build.gradle.kts
│   │   ├── src/main/kotlin/com/sen/banc/Application.kt
│   │   ├── src/main/kotlin/com/sen/banc/accounts/
│   │   ├── src/main/kotlin/com/sen/banc/cards/
│   │   └── src/main/kotlin/com/sen/banc/transfers/
│   └── flutter/               ← app Flutter multi-plateforme
│       ├── pubspec.yaml
│       └── lib/main.dart
│
├── sencrypt/                  ← exchange crypto (Go + React)
│   ├── backend/               ← Go services
│   │   ├── go.mod
│   │   ├── cmd/server/main.go
│   │   ├── internal/matching/ ← matching engine simplifié
│   │   ├── internal/wallet/
│   │   └── internal/p2p/
│   └── web/                   ← React + TypeScript + TradingView
│       ├── package.json
│       └── src/App.tsx
│
└── tax_engine/                ← moteur fiscal IA multi-juridictions
    ├── main.py                ← FastAPI
    ├── jurisdictions/         ← règles fiscales par pays
    │   ├── senegal.py
    │   ├── france.py
    │   ├── usa.py
    │   ├── uk.py
    │   ├── eu_dac8.py
    │   └── africa.py
    ├── ai_classifier.py       ← classification événements imposables
    └── requirements.txt
```

---

## 🚀 Démarrage rapide (5 minutes)

### 1. Prérequis
- Docker + Docker Compose
- Node.js 20+
- Python 3.11+
- Java 17 (pour SENBANC)
- Go 1.21+ (pour SENCRYPT)
- Flutter 3.16+ (pour SENBANC mobile)

### 2. Stack locale (1 commande)
```bash
docker-compose up -d
```

Lance automatiquement :
- PostgreSQL (port 5432)
- Redis (port 6379)
- Kafka + Zookeeper (port 9092)
- Elasticsearch (port 9200)
- MongoDB (port 27017)
- MinIO (S3 compatible, port 9000)

### 3. Lancer les 3 backends
```bash
# SEN TEW
cd sen_tew/backend && npm install && npm run start:dev

# SENBANC
cd senbanc/backend && ./gradlew bootRun

# SENCRYPT
cd sencrypt/backend && go run cmd/server/main.go

# Tax Engine
cd tax_engine && pip install -r requirements.txt && uvicorn main:app --reload
```

### 4. Lancer les frontends
```bash
# SEN TEW Web
cd sen_tew/web && npm install && npm run dev          # → http://localhost:3000

# SENBANC Flutter
cd senbanc/flutter && flutter run -d chrome           # → web Flutter

# SENCRYPT Web
cd sencrypt/web && npm install && npm run dev         # → http://localhost:3002

# Landing hub
cd landing_hub && python3 -m http.server 8080         # → http://localhost:8080
```

---

## 🔐 Variables d'environnement

Voir `.env.example`. Les clés critiques (Stripe, Wave API, Fireblocks, BCEAO) doivent être obtenues via **Vault HashiCorp** ou **AWS Secrets Manager** en production.

---

## 🏗️ Architecture cible production

- **Cloud** : AWS af-south-1 (Cape Town) + Sonatel Dakar datacenter
- **Orchestration** : Kubernetes (EKS)
- **CDN** : Cloudflare
- **Monitoring** : Datadog + Sentry
- **CI/CD** : GitHub Actions + ArgoCD

---

## 📞 Contact

- 🌐 https://sen-ecosystem.com
- 📧 dev@sen-ecosystem.com
- 💬 Slack: sen-ecosystem.slack.com

---

**© 2026 SEN HOLDING SAS — Tous droits réservés**
