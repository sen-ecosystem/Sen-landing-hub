package com.sen.banc

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.kafka.annotation.EnableKafka
import org.springframework.scheduling.annotation.EnableAsync
import org.springframework.scheduling.annotation.EnableScheduling

@SpringBootApplication
@EnableKafka
@EnableAsync
@EnableScheduling
class SenbancApplication

fun main(args: Array<String>) {
    runApplication<SenbancApplication>(*args)
    println("🏦 SENBANC backend started — Revolut-grade neobank for Africa")
}
