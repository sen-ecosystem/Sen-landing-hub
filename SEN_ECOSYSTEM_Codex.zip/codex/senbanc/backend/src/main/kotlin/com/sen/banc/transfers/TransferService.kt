package com.sen.banc.transfers

import org.springframework.stereotype.Service
import org.springframework.kafka.core.KafkaTemplate
import java.math.BigDecimal
import java.time.Instant
import java.util.UUID

/**
 * SENBANC — Service de transferts (modalités Revolut)
 *
 * Méthodes supportées :
 *  - SEPA Instant (< 10s)
 *  - SEPA Standard
 *  - SWIFT international
 *  - GIM-UEMOA (XOF)
 *  - TARGET2
 *  - Faster Payments UK
 *  - ACH USA
 *  - Mobile Money (Wave, Orange Money, M-Pesa, MTN)
 *  - Transferts internes SENBANC (instantané gratuit)
 *  - Pont vers SENCRYPT (crypto)
 */
@Service
class TransferService(
    private val kafkaTemplate: KafkaTemplate<String, Any>,
    private val complianceService: ComplianceService,
    private val fxService: FxService,
    private val fraudEngine: AntiFraudEngine,
) {

    enum class TransferMethod {
        SEPA_INSTANT, SEPA_STANDARD, SWIFT, GIM_UEMOA, TARGET2,
        FASTER_PAYMENTS_UK, ACH_USA, WAVE, ORANGE_MONEY, FREE_MONEY,
        WIZALL, MPESA, MTN_MOMO, AIRTEL_MONEY,
        SENBANC_INTERNAL, SENCRYPT_BRIDGE, CASH_PICKUP
    }

    enum class TransferStatus { PENDING_KYC, PENDING_AML, PENDING_FRAUD, APPROVED, REJECTED, COMPLETED, FAILED }

    data class TransferRequest(
        val fromAccountId: UUID,
        val toIdentifier: String,        // IBAN, telephone, email, adresse crypto
        val amount: BigDecimal,
        val sourceCurrency: String,
        val targetCurrency: String,
        val method: TransferMethod,
        val reference: String? = null,
        val urgent: Boolean = false,
    )

    data class TransferResult(
        val transferId: UUID,
        val status: TransferStatus,
        val estimatedArrival: Instant,
        val feeCharged: BigDecimal,
        val exchangeRate: BigDecimal?,
        val recipientAmount: BigDecimal,
    )

    fun processTransfer(req: TransferRequest): TransferResult {
        val transferId = UUID.randomUUID()

        // 1) Anti-fraude IA temps réel (500+ signaux comme Binance/Revolut)
        val fraudScore = fraudEngine.scoreTransfer(req)
        if (fraudScore > 80) {
            return TransferResult(transferId, TransferStatus.REJECTED, Instant.now(), BigDecimal.ZERO, null, BigDecimal.ZERO)
        }

        // 2) Vérifications conformité (AML, sanctions, KYC)
        val complianceOk = complianceService.checkTransfer(req)
        if (!complianceOk) {
            return TransferResult(transferId, TransferStatus.PENDING_AML, Instant.now(), BigDecimal.ZERO, null, BigDecimal.ZERO)
        }

        // 3) Conversion devise si nécessaire
        val (recipientAmount, rate) = if (req.sourceCurrency != req.targetCurrency) {
            fxService.convert(req.amount, req.sourceCurrency, req.targetCurrency)
        } else {
            req.amount to BigDecimal.ONE
        }

        // 4) Calcul des frais (modèle Revolut)
        val fee = calculateFee(req)

        // 5) Routage selon méthode
        val arrival = estimateArrival(req.method, req.urgent)

        // 6) Publication événement Kafka (event sourcing CQRS comme Revolut)
        kafkaTemplate.send("senbanc.transfers.initiated", transferId.toString(), mapOf(
            "transferId" to transferId,
            "method" to req.method.name,
            "amount" to req.amount,
            "currency" to req.sourceCurrency,
            "recipientAmount" to recipientAmount,
            "fee" to fee,
            "fraudScore" to fraudScore,
        ))

        return TransferResult(transferId, TransferStatus.APPROVED, arrival, fee, rate, recipientAmount)
    }

    private fun calculateFee(req: TransferRequest): BigDecimal = when (req.method) {
        TransferMethod.SENBANC_INTERNAL,
        TransferMethod.SEPA_INSTANT,
        TransferMethod.SEPA_STANDARD,
        TransferMethod.WAVE,
        TransferMethod.ORANGE_MONEY,
        TransferMethod.GIM_UEMOA -> BigDecimal.ZERO
        TransferMethod.SWIFT -> BigDecimal("5.00") + req.amount.multiply(BigDecimal("0.001"))
        TransferMethod.SENCRYPT_BRIDGE -> req.amount.multiply(BigDecimal("0.005"))
        else -> req.amount.multiply(BigDecimal("0.005"))
    }

    private fun estimateArrival(method: TransferMethod, urgent: Boolean): Instant {
        val now = Instant.now()
        return when (method) {
            TransferMethod.SENBANC_INTERNAL,
            TransferMethod.WAVE, TransferMethod.ORANGE_MONEY,
            TransferMethod.FREE_MONEY, TransferMethod.WIZALL,
            TransferMethod.MPESA, TransferMethod.MTN_MOMO -> now.plusSeconds(5)
            TransferMethod.SEPA_INSTANT -> now.plusSeconds(10)
            TransferMethod.FASTER_PAYMENTS_UK -> now.plusSeconds(120 * 60L)
            TransferMethod.GIM_UEMOA -> now.plusSeconds(2 * 3600L)
            TransferMethod.SEPA_STANDARD -> now.plusSeconds(24 * 3600L)
            TransferMethod.ACH_USA -> now.plusSeconds(2 * 24 * 3600L)
            TransferMethod.SWIFT -> now.plusSeconds(3 * 24 * 3600L)
            TransferMethod.SENCRYPT_BRIDGE -> now.plusSeconds(30 * 60L)
            else -> now.plusSeconds(3600L)
        }
    }
}

interface ComplianceService { fun checkTransfer(req: TransferService.TransferRequest): Boolean }
interface FxService { fun convert(amount: BigDecimal, from: String, to: String): Pair<BigDecimal, BigDecimal> }
interface AntiFraudEngine { fun scoreTransfer(req: TransferService.TransferRequest): Int }
