// SENBANC — Application Flutter (mobile + web)
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() => runApp(const SenbancApp());

class SenbancApp extends StatelessWidget {
  const SenbancApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SENBANC',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0F6B4E),
          primary: const Color(0xFF0F6B4E),
          secondary: const Color(0xFFD4A574),
          surface: const Color(0xFFFAFAF7),
        ),
        textTheme: GoogleFonts.interTextTheme(),
      ),
      home: const HomeDashboard(),
    );
  }
}

class HomeDashboard extends StatelessWidget {
  const HomeDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SENBANC',
          style: TextStyle(color: Color(0xFFD4A574), fontWeight: FontWeight.w900, letterSpacing: 3)),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      backgroundColor: const Color(0xFFFAFAF7),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _balanceCard(),
          const SizedBox(height: 20),
          _quickActions(),
          const SizedBox(height: 30),
          const Text('Transactions récentes',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF0F6B4E))),
          const SizedBox(height: 12),
          _txItem('Aïcha Boutique', '-25 000 FCFA', 'Achat SEN TEW'),
          _txItem('Salaire entreprise', '+850 000 FCFA', 'Virement'),
          _txItem('Wave', '-15 000 FCFA', 'Transfert sortant'),
          _txItem('Maman Diop', '+50 EUR', 'Reçu de la diaspora'),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: Colors.black,
        indicatorColor: const Color(0xFFD4A574),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home, color: Colors.white), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.credit_card, color: Colors.white), label: 'Cartes'),
          NavigationDestination(icon: Icon(Icons.swap_horiz, color: Colors.white), label: 'Transferts'),
          NavigationDestination(icon: Icon(Icons.savings, color: Colors.white), label: 'Épargne'),
          NavigationDestination(icon: Icon(Icons.person, color: Colors.white), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _balanceCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFD4A574), Color(0xFFB88B5A)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.15), blurRadius: 20, offset: const Offset(0,10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Text('Compte Principal', style: TextStyle(color: Colors.white70, fontSize: 14)),
          SizedBox(height: 8),
          Text('1 245 800 FCFA',
            style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
          SizedBox(height: 8),
          Text('+ 850 EUR · 320 USD · 180 GBP', style: TextStyle(color: Colors.white70, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _quickActions() {
    final actions = [
      ['Envoyer', Icons.arrow_upward],
      ['Recevoir', Icons.arrow_downward],
      ['Payer', Icons.qr_code_scanner],
      ['Échanger', Icons.swap_horiz],
    ];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: actions.map((a) => Column(
        children: [
          CircleAvatar(
            radius: 28, backgroundColor: const Color(0xFF0F6B4E),
            child: Icon(a[1] as IconData, color: Colors.white),
          ),
          const SizedBox(height: 8),
          Text(a[0] as String, style: const TextStyle(fontSize: 12)),
        ],
      )).toList(),
    );
  }

  Widget _txItem(String name, String amount, String desc) {
    final isPositive = amount.startsWith('+');
    return Card(
      elevation: 0, color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFE8F4EE), child: Icon(Icons.swap_horiz, color: Color(0xFF0F6B4E))),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(desc),
        trailing: Text(amount, style: TextStyle(
          fontWeight: FontWeight.bold,
          color: isPositive ? const Color(0xFF0F6B4E) : Colors.black87,
        )),
      ),
    );
  }
}
